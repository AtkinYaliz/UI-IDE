Please note that it is forbidden to use this typeface for your commercial project.

## LICENSING

The typeface is licensed to registered third-party developers for the design and development of applications for iOS, macOS and watchOS
